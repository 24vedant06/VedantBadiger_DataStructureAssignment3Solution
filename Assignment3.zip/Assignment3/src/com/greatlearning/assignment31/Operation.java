package com.greatlearning.assignment31;

import java.util.PriorityQueue;

public class Operation {
	
	public void printConstructionTable(int[] floors, int totalFloors) {
		System.out.println("Order of placins floor with respect to size and day is : ");
		PriorityQueue<Integer> queue = new PriorityQueue<>(java.util.Collections.reverseOrder());
		int[] temp = new int[totalFloors];
		int n = totalFloors;
		System.out.println();
		for (int i = 0; i < totalFloors; i++) {
			System.out.println("Day: "+(i+1));
			temp[i] = floors[i];
			queue.add(temp[i]);
			while (!queue.isEmpty() && queue.peek() == n) {
				System.out.print(queue.poll() + " ");
				n--;
				System.out.println();
			}
		}
		
	}

}
