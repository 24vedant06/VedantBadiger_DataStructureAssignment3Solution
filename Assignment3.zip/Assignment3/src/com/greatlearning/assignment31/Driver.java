package com.greatlearning.assignment31;
import java.util.Scanner;
public class Driver {

	public static void main(String[] args) {
		
				Scanner sc = new Scanner(System.in);
				System.out.println("Please provide the no of floors in building");
				int totalFloors = sc.nextInt();
				int[] floors = new int[totalFloors];
				for(int i=0; i<totalFloors; i++)  
				{  
					System.out.println("Give the floor size of the day : "+(i+1));
					floors[i] = sc.nextInt(); 
				}  
				Operation operation = new Operation();
				operation.printConstructionTable(floors, totalFloors);
			
			}
		

	}


