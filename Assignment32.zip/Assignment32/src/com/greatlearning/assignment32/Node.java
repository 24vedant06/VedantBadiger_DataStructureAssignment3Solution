package com.greatlearning.assignment32;

public class Node {
	int num;
	Node left, right;

	Node(int temp) {
		num = temp;
		left = right = null;
	}
}
